import {useState,useEffect} from 'react';import AgentCard from '@/components/AgentCard';
export default function Home(){
 const [agents,setAgents]=useState([]);const [stateF,setStateF]=useState('All');const [typeF,setTypeF]=useState('All');
 useEffect(()=>{fetch('/data/agents.json').then(r=>r.json()).then(setAgents)},[])
 const filtered=agents.filter(a=>(stateF==='All'||a.state===stateF)&&(typeF==='All'||a.leads_type===typeF));
 return(<div className="container">
  <h1>BrokerMatch AI MVP</h1>
  <select onChange={e=>setStateF(e.target.value)}><option>All</option><option>Washington</option><option>Arizona</option></select>
  <select onChange={e=>setTypeF(e.target.value)}><option>All</option><option>New Agent</option><option>Switched Brokerages</option><option>Dropped Lender</option><option>High Volume</option></select>
  {filtered.map((a,i)=><AgentCard key={i} agent={a}/>)}
 </div>) }