export default function AgentCard({ agent }){
  const copy=async()=>{await navigator.clipboard.writeText(agent.outreach_message);alert('Message copied!')}
  return(<div className="card">
    <h3>{agent.name} – {agent.state}</h3>
    <div className="badge">{agent.leads_type}</div>
    <p><b>Brokerage:</b> {agent.brokerage}</p>
    <p><b>Volume:</b> {agent.volume_last_12mo} | <b>Last:</b> {agent.last_activity}</p>
    <p><b>Email:</b> {agent.email} | <b>Phone:</b> {agent.phone}</p>
    <p>{agent.outreach_message}</p>
    <button onClick={copy}>Copy Outreach</button>
  </div>) }